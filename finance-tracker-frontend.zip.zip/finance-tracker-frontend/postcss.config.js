module.exports = {
  plugins: {
    '@tailwindcss/postcss': {}, // Correct plugin
    autoprefixer: {},
  },
};