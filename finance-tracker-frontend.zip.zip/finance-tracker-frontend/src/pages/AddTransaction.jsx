import React, { useState } from "react";
import axios from "axios";

export default function AddTransaction({ onAdd }) {
  const [formData, setFormData] = useState({
    title: "",
    amount: "",
    type: "income",
    category: "",
    date: "",
  });

  const handleChange = (e) =>
    setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post(
        "http://localhost:5000/api/transactions",
        formData
      );
      onAdd(res.data);
      setFormData({
        title: "",
        amount: "",
        type: "income",
        category: "",
        date: "",
      });
    } catch (err) {
      alert("Network Error - Backend not reachable!");
    }
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="bg-white p-4 rounded-xl shadow space-y-3 mt-6"
    >
      <h2 className="text-xl font-semibold mb-2">Add New Transaction</h2>
      <input
        name="title"
        value={formData.title}
        onChange={handleChange}
        placeholder="Title"
        required
        className="border p-2 w-full rounded"
      />
      <input
        name="amount"
        type="number"
        value={formData.amount}
        onChange={handleChange}
        placeholder="Amount"
        required
        className="border p-2 w-full rounded"
      />
      <select
        name="type"
        value={formData.type}
        onChange={handleChange}
        className="border p-2 w-full rounded"
      >
        <option value="income">Income</option>
        <option value="expense">Expense</option>
      </select>
      <input
        name="category"
        value={formData.category}
        onChange={handleChange}
        placeholder="Category"
        required
        className="border p-2 w-full rounded"
      />
      <input
        type="date"
        name="date"
        value={formData.date}
        onChange={handleChange}
        required
        className="border p-2 w-full rounded"
      />
      <button
        type="submit"
        className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600"
      >
        Add Transaction
      </button>
    </form>
  );
}


