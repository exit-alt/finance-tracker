import React, { useState, useEffect } from "react";
import axios from "axios";
import Dashboard from "./pages/Dashboard";
import AddTransaction from "./pages/AddTransaction";

function App() {
  const [transactions, setTransactions] = useState([]);

  useEffect(() => {
    axios
      .get("http://localhost:5000/api/transactions")
      .then((res) => setTransactions(res.data))
      .catch(() => alert("Cannot fetch data from backend"));
  }, []);

  const handleAddTransaction = (newTransaction) => {
    setTransactions([...transactions, newTransaction]);
  };

  return (
    <div className="p-6 bg-gray-100 min-h-screen">
      <h1 className="text-3xl font-bold mb-4 text-center">Finance Tracker</h1>
      <Dashboard transactions={transactions} />
      <AddTransaction onAdd={handleAddTransaction} />
    </div>
  );
}

export default App;

