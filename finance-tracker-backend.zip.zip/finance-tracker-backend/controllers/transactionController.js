const Transaction = require('../models/Transaction');

// GET /api/transactions
exports.getAll = async (req, res) => {
  try {
    const items = await Transaction.find().sort({ createdAt: -1 });
    res.json(items);
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};

// POST /api/transactions
exports.create = async (req, res) => {
  try {
    const { title, amount, type, category, date, note } = req.body;

    if (!title || amount == null || !type) {
      return res.status(400).json({ message: 'title, amount, type are required' });
    }

    const tx = await Transaction.create({
      title,
      amount,
      type,
      category,
      date,
      note,
    });

    res.status(201).json(tx);
  } catch (err) {
    res.status(400).json({ message: 'Invalid data', error: err.message });
  }
};

// PUT /api/transactions/:id
exports.update = async (req, res) => {
  try {
    const tx = await Transaction.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
    });
    if (!tx) return res.status(404).json({ message: 'Not found' });
    res.json(tx);
  } catch (err) {
    res.status(400).json({ message: 'Invalid data', error: err.message });
  }
};

// DELETE /api/transactions/:id
exports.remove = async (req, res) => {
  try {
    const tx = await Transaction.findByIdAndDelete(req.params.id);
    if (!tx) return res.status(404).json({ message: 'Not found' });
    res.json({ message: 'Deleted', id: tx._id });
  } catch (err) {
    res.status(400).json({ message: 'Invalid id', error: err.message });
  }
};

// GET /api/transactions/summary
exports.summary = async (req, res) => {
  try {
    const agg = await Transaction.aggregate([
      {
        $group: {
          _id: '$type',
          total: { $sum: '$amount' },
        },
      },
    ]);

    const income = agg.find((a) => a._id === 'income')?.total || 0;
    const expense = agg.find((a) => a._id === 'expense')?.total || 0;

    res.json({
      income,
      expense,
      balance: income - expense,
    });
  } catch (err) {
    res.status(500).json({ message: 'Server error', error: err.message });
  }
};
